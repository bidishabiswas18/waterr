import unittest
from logic import validate_report, classify_report, dfa_accepts_station, dfa_accepts_parameter

class ValidationTests(unittest.TestCase):
    def test_valid_station_examples(self):
        for s in ["WSNTH1","WSSTH12","WSEST123","WSWST007"]:
            self.assertTrue(dfa_accepts_station(s))
    def test_invalid_station_examples(self):
        for s in ["WSXYZ1","WSNTH","WSNTH1234","WSNTHA1","WNTH12",""]:
            self.assertFalse(dfa_accepts_station(s))
    def test_valid_parameter_examples(self):
        self.assertTrue(dfa_accepts_parameter("P01"))
        self.assertTrue(dfa_accepts_parameter("P99"))
    def test_invalid_parameter_examples(self):
        for p in ["P1","P001","PX1","pA1",""]:
            self.assertFalse(dfa_accepts_parameter(p))
    def test_dfa_regex_agreement(self):
        for s in ["WSNTH1","WSXYZ1","WSSTH123","WSWST1234"]:
            d={"reporter_name":"A","station_code":s,"parameter_code":"P01","description":"mud","urgency":"Normal"}
            out=validate_report(d)
            self.assertEqual(out["dfa_station"],out["regex_station"])
    def test_missing_fields(self):
        self.assertFalse(validate_report({})["valid"])
    def test_parameter_validation(self):
        d={"reporter_name":"A","station_code":"WSNTH1","parameter_code":"P1","description":"mud","urgency":"Normal"}
        self.assertFalse(validate_report(d)["valid"])
    def test_complete_valid_report(self):
        d={"reporter_name":"A","station_code":"WSNTH1","parameter_code":"P01","description":"muddy water","urgency":"Normal"}
        self.assertTrue(validate_report(d)["valid"])

class ClassificationTests(unittest.TestCase):
    def test_chemical(self): self.assertEqual(classify_report("chemical smell in water")[0],"Chemical")
    def test_biological(self): self.assertEqual(classify_report("bacteria detected")[0],"Biological")
    def test_physical(self): self.assertEqual(classify_report("muddy cloudy water")[0],"Physical")
    def test_pressure(self): self.assertEqual(classify_report("low pressure and weak flow")[0],"Pressure")
    def test_supply(self): self.assertEqual(classify_report("water supply interruption")[0],"Supply")
    def test_tie_rule(self): self.assertEqual(classify_report("chemical bacteria")[0],"Chemical")
    def test_default_category(self): self.assertEqual(classify_report("unusual water complaint")[0],"Physical")

if __name__ == "__main__": unittest.main()
