const $ = (id) => document.getElementById(id);
async function api(url, options={}) {
  const res = await fetch(url, {headers:{"Content-Type":"application/json"}, ...options});
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || data.validation?.message || "Request failed");
  return data;
}
function showValidation(text, good=false){$("validation").textContent=text;$("validation").className="validation "+(good?"good":"bad");}
$("reportForm").addEventListener("submit", async e=>{
  e.preventDefault(); const data=Object.fromEntries(new FormData(e.target).entries());
  try{
    const result=await api("/api/reports",{method:"POST",body:JSON.stringify(data)});
    showValidation(result.report.validation_message,true);
    $("created").classList.remove("hidden");
    $("created").innerHTML=`<b>Report submitted successfully · ID #${result.report.id}</b><br>Category: ${result.report.category} · Priority: ${result.report.priority}<br>Assigned handler: ${result.report.assigned_handler||"Pending queue"}<br>Status: ${result.report.status}<br><small>${result.dispatch.note}</small>`;
    e.target.reset(); await refresh();
  }catch(err){showValidation(err.message,false);$("created").classList.add("hidden");}
});
$("trackBtn").onclick=async()=>{
 const id=$("trackId").value;if(!id){$("trackResult").textContent="Enter a report ID.";return;}
 try{const r=await api("/api/reports/"+id);$("trackResult").innerHTML=`<b>Report #${r.id}</b> · ${r.category} · ${r.priority}<br>Status: <b>${r.status}</b> · Handler: ${r.assigned_handler||"Not assigned"}<br>Station: ${r.station_code} · Submitted: ${r.created_at}`;}
 catch(e){$("trackResult").textContent=e.message;}
};
async function loadAll(){
 const rows=await api("/api/reports");
 $("reportsBody").innerHTML=rows.map(r=>`<tr><td>#${r.id}</td><td>${r.station_code}</td><td>${r.category}</td><td><span class="pill ${r.priority}">${r.priority}</span></td><td>${r.assigned_handler||"Queue"}</td><td><span class="pill ${r.status}">${r.status}</span></td><td><select class="inline-select" onchange="setStatus(${r.id},this.value)">${["Pending","Assigned","In Progress","Resolved"].map(s=>`<option ${s===r.status?"selected":""}>${s}</option>`).join("")}</select></td></tr>`).join("") || '<tr><td colspan="7">No reports yet.</td></tr>';
}
async function setStatus(id,status){try{await api(`/api/reports/${id}/status`,{method:"PATCH",body:JSON.stringify({status})});await refresh();}catch(e){alert(e.message);}}
async function loadHandlers(){
 const rows=await api("/api/handlers");
 $("handlersBody").innerHTML=rows.map(h=>`<tr><td>${h.name}</td><td>${h.zone}</td><td>${h.role}</td><td>${h.current_load} / ${h.capacity}</td><td>${h.available?"Yes":"No"}</td><td><div class="handler-controls"><input id="cap${h.id}" type="number" min="0" value="${h.capacity}" title="Capacity"><select id="avail${h.id}" class="inline-select"><option value="1" ${h.available?"selected":""}>Available</option><option value="0" ${!h.available?"selected":""}>Unavailable</option></select><button class="secondary" onclick="saveHandler(${h.id})">Save</button></div></td></tr>`).join("");
}
async function saveHandler(id){try{await api(`/api/handlers/${id}`,{method:"PATCH",body:JSON.stringify({capacity:$("cap"+id).value,available:$("avail"+id).value==="1"})});await refresh();}catch(e){alert(e.message);}}
function bars(el,items){const max=Math.max(1,...items.map(x=>x.value));$(el).innerHTML=items.length?items.map(x=>`<div class="bar-row"><div class="bar-label"><span>${x.label}</span><b>${x.value}</b></div><div class="bar"><span style="width:${x.value/max*100}%"></span></div></div>`).join(""):"<small>No data yet.</small>";}
async function loadAnalytics(){
 const a=await api("/api/analytics");$("totalCount").textContent=a.total;$("heroTotal").textContent=a.total;
 const resolved=a.by_status.find(x=>x.label==="Resolved")?.value||0,pending=a.by_status.find(x=>x.label==="Pending")?.value||0;
 $("resolvedCount").textContent=resolved;$("heroResolved").textContent=resolved;$("pendingCount").textContent=pending;
 $("activeCount").textContent=a.by_status.filter(x=>["Assigned","In Progress"].includes(x.label)).reduce((n,x)=>n+x.value,0);
 bars("categoryChart",a.by_category);bars("zoneChart",a.by_zone);bars("statusChart",a.by_status);
}
async function loadRouting(){
 const r=await api("/api/routing");
 $("routingSummary").innerHTML=`<div class="route-box"><b>Two-tier routing rules</b><br>Chemical / Biological → Zonal Quality Officer (immediate escalation).<br>Physical / Pressure / Supply → zone lookup (NTH, STH, EST, WST) → nearest field team.<br>Unavailable/full → backup team → priority-ordered Pending queue.</div><div class="route-box"><b>Pending queue (${r.queue.length})</b><br>${r.queue.map(q=>`#${q.id} · ${q.priority} · ${q.category} · ${q.station_code}`).join("<br>")||"No queued reports."}</div>`;
}
async function refresh(){await Promise.all([loadAll(),loadHandlers(),loadAnalytics(),loadRouting()]);}
refresh().catch(e=>console.error(e));
